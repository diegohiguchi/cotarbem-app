# Changelog

## 1.2.4 (Oct 27 2015)

Fix changes not getting committed on blur when ng-model-options="{updateOn: 'blur'}".

## 1.2.3 (Oct 27 2015)

Point "main" to dist for bower.

## 1.2.2 (Oct 23 2015)

Build dist.

## 1.2.1 (Oct 23 2015)

Fix #17 (again) and #28 (bad release — forgot to build dist)

## 1.2.0 (Oct 11 2015)

Support for Angular 1.3 and up.

## 1.1.1 (Oct 11 2015)

Fixed the shitshow in 1.1.0. I'm sorry about that :(

## 1.1.0 (Feb 16 2015)

 Made `min`, `max` and `precision` attributes dynamic.

## 1.0.2 (Aug 6 2014)

This is the last version where things were mostly working swimmingly on Angular 1.2.
