(function () {
    'use strict';
    var controllerId = 'login';

    //function login($rootScope, $location, services, autenticacao, load, $ionicUser, $ionicPush) {
    function login($rootScope, $location, services, autenticacao, load, deviceToken, $ionicPush, $ionicUser) {
        var vm = this;
        var tipoUsuario = {};
        var response = {};
        vm.viewLogin = true;
        vm.usuario = {
            email: '',
            password: ''
        };

        vm.switchTab = function (tab) {
            if (tab === 'login') {
                vm.viewLogin = true;
            } else {
                vm.viewLogin = false;
            }
        }

        $rootScope.$on('$cordovaPush:tokenReceived', function (event, data) {
            console.log('Got token', data.token, data.platform);
            adicionarDeviceToken(data.token);
        });

        function obterTipoUsuarioPorId(tipoUsuarioId) {
            services.tipoUsuarioServices.obterPorId(tipoUsuarioId).success(function (response) {
                tipoUsuario = response.data;
            }).then(function () {
                if (tipoUsuario.nome === 'Fornecedor')
                    $location.path('/app/solicitacao/fornecedor');
                else if (tipoUsuario.nome === 'Cliente')
                    $location.path('/app/solicitacao/cliente');
                else if (tipoUsuario.nome == 'Administrador')
                    $location.path('/app/categoria');

                load.hideLoading();
                if (typeof callback === 'function') {
                    callback();
                }
            });
        }

        /*function editarDeviceToken(device) {
         services.deviceTokenServices.editar(device).success(function (response) {
         });
         }

         function obterDeviceToken(response) {
         var tokenAndroid = deviceToken.getDeviceToken();

         if (tokenAndroid) {
         var device = {
         usuarioId: response.user._id,
         token: tokenAndroid
         }

         editarDeviceToken(device);
         }

         }*/

        function adicionarDeviceToken(token) {
            var usuario = autenticacao.getUser();

            var device = {
                usuarioId: usuario._id,
                token: token
            }

            services.deviceTokenServices.register(device).then(function (response) {
                /* deviceToken.setDeviceToken(appDeviceToken);
                 deviceToken.setToken({
                 token: response.token,
                 expires: response.expires
                 });*/
                //alert('registered!');
            });
        }

        function obterDeviceToken() {
            //Basic registration
            //vm.pushRegister = function() {
            alert('Registering...');

            $ionicPush.register({
                canShowAlert: false,
                onNotification: function (notification) {
                    // Called for each notification for custom handling
                    vm.lastNotification = JSON.stringify(notification);
                }
            }).then(function (deviceToken) {
                vm.token = deviceToken;
                //adicionarDeviceToken(vm.token);
                console.log(vm.token);
            });
            //}
        }

        function identificarUsuario() {
            alert('Identifying');
            console.log('Identifying user');

            var user = $ionicUser.get();
            if (!user.user_id) {
                // Set your user_id here, or generate a random one
                user.user_id = $ionicUser.generateGUID()
            }

            angular.extend(user, {
                name: 'Test User',
                message: 'I come from planet Ion'
            });

            $ionicUser.identify(user);
        }

        vm.login = function (usuario) {
            load.showLoading('Autenticando...');

            services.loginServices.login(usuario).success(function (response) {

                response = response.data;
                autenticacao.setUser(response.user);
                autenticacao.setToken({
                    token: response.token,
                    expires: response.expires
                });

                $rootScope.isAuthenticated = true;

                //obterDeviceToken(response);
                identificarUsuario();
                obterDeviceToken();
                obterTipoUsuarioPorId(response.user.tipoUsuarioId);
                //$scope.modal.hide();
            }).error(function (err, statusCode) {

                load.hideLoading();
                load.toggleLoadingWithMessage(err.message);

            });
        }

        vm.registrar = function (usuario) {
            load.showLoading('Registrando...');

            services.loginServices.registrar(usuario).success(function (response) {

                response = response.data;
                autenticacao.setUser(response.user);
                autenticacao.setToken({
                    token: response.token,
                    expires: response.expires
                });

                $rootScope.isAuthenticated = true;

                //obterDeviceToken(response);
                identificarUsuario();
                obterDeviceToken();
                obterTipoUsuarioPorId(response.user.tipoUsuarioId);
            }).error(function (err, statusCode) {
                load.hideLoading();
                load.toggleLoadingWithMessage(err.message);
            });
        }

        /*vm.identifyUser = function() {
         var user = $ionicUser.get();
         if(!user.user_id) {
         // Set your user_id here, or generate a random one.
         user.user_id = $ionicUser.generateGUID();
         };

         // Metadata
         angular.extend(user, {
         name: 'Up',
         bio: 'Author of Sites Web'
         });

         // Identify your user with the Ionic User Service
         $ionicUser.identify(user).then(function(){
         vm.identified = true;
         console.log('Identified user ' + user.name + '\n ID ' + user.user_id);
         });
         };

         vm.pushRegister = function() {
         console.log('Ionic Push: Registering user');

         // Register with the Ionic Push service.  All parameters are optional.
         $ionicPush.register({
         canShowAlert: true, //Can pushes show an alert on your screen?
         canSetBadge: true, //Can pushes update app icon badges?
         canPlaySound: true, //Can notifications play a sound?
         canRunActionsOnWake: true, //Can run actions outside the app,
         onNotification: function(notification) {
         // Handle new push notifications here
         return true;
         }
         });
         };

         $rootScope.$on('$cordovaPush:tokenReceived', function(event, data) {
         alert("Successfully registered token " + data.token);
         console.log('Ionic Push: Got token ', data.token, data.platform);
         vm.token = data.token;
         });*/
    }

    angular.module('cotarApp').controller(controllerId, ['$rootScope', '$location', 'services', 'autenticacao', 'load',
        'deviceToken', '$ionicPush', '$ionicUser', login]);
    //angular.module('cotarApp').controller(controllerId, ['$rootScope', '$location', 'services', 'autenticacao', 'load', '$ionicUser', '$ionicPush', login]);

})();