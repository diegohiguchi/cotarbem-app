(function () {
    'use strict';

    var connectionId = 'connection';

    function connection() {
        var baseDesenvolvimento = 'http://localhost:3000';
        var baseProducao = 'http://cotar-bem.herokuapp.com';
        var baseNgrok = 'http://eebe0164.ngrok.io';

        function base() {
            return baseNgrok;
        }

        var connections = {
            base: base
        };

        return connections;
    }

    angular.module('cotarApp').factory(connectionId, [connection]);
})();