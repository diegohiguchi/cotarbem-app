(function () {
    'use strict';

    var loginServicesId = 'loginServices';

    function loginServices($http, autenticacao, connection) {

        function login(usuario) {
            return $http.post(connection.base() + '/autenticacao/login', usuario);
        }

        function registrar(usuario) {
            return $http.post(connection.base() + '/autenticacao/registrar', usuario);
        }

        function logout() {
            autenticacao.deleteAuth();
        }

        var services = {
            login: login,
            registrar: registrar,
            logout: logout
        };

        return services;
    }

    angular.module('cotarApp').factory(loginServicesId, ['$http', 'autenticacao', 'connection', loginServices]);
})();