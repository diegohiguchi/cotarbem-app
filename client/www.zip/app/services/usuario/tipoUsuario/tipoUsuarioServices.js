(function () {
    'use strict';

    var tipoUsuarioServicesId = 'tipoUsuarioServices';

    function tipoUsuarioServices($http, connection) {

        function obterPorId(id) {
            return $http.get(connection.base() + '/tipoUsuario/obterPorId/' + id);
        }

        var services = {
            obterPorId: obterPorId
        };

        return services;
    }

    angular.module('cotarApp').factory(tipoUsuarioServicesId, ['$http', 'connection', tipoUsuarioServices]);
})();
