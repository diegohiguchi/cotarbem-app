(function () {
    'use strict';

    var categoriaServicesId = 'categoriaServices';

    function categoriaServices($http, connection) {

        function obterTodas() {
            return $http.get(connection.base() + '/categoria/obterTodas');
        }

        function obterPorId(id) {
            return $http.get(connection.base() + '/categoria/obterPorId/' + id);
        }

        function adicionar(categoria){
            return $http.post(connection.base() + '/categoria/adicionar', categoria);
        }

        function editar(categoria){
            return $http.post(connection.base() + '/categoria/editar', categoria);
        }

        function remover(id){
            return $http.post(connection.base() + '/categoria/remover/'+ id);
        }

        var services = {
            obterTodas: obterTodas,
            obterPorId: obterPorId,
            adicionar: adicionar,
            editar: editar,
            remover: remover
        };

        return services;
    }

    angular.module('cotarApp').factory(categoriaServicesId, ['$http', 'connection', categoriaServices]);
})();
