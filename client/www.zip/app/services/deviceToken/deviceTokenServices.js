(function () {
    'use strict';

    var deviceTokenServicesId = 'deviceTokenServices';

    function deviceTokenServices($http, connection) {

        function register(deviceToken){
            return $http.post(connection.base() + '/register', {'deviceToken': deviceToken});
        }

        function editar(device){
            return $http.post(connection.base() + '/deviceToken/editar', device);
        }

        function notificar(device) {
            return $http.post(connection.base() + '/deviceToken/notificar', device);
        }

        var services = {
            register: register,
            editar: editar,
            notificar: notificar
        };

        return services;
    }

    angular.module('cotarApp').factory(deviceTokenServicesId, ['$http', 'connection', deviceTokenServices]);
})();
