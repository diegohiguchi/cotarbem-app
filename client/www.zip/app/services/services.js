(function () {
    'use strict';

    var serviceId = 'services';

    function services(loginServices, tipoUsuarioServices, categoriaServices, cotacaoServices, usuarioServices, solicitacaoServices,
                      produtoServices, deviceTokenServices, lanceServices, salaServices) {
        var service = {
            loginServices: loginServices,
            tipoUsuarioServices: tipoUsuarioServices,
            categoriaServices: categoriaServices,
            cotacaoServices: cotacaoServices,
            usuarioServices: usuarioServices,
            solicitacaoServices: solicitacaoServices,
            produtoServices: produtoServices,
            deviceTokenServices: deviceTokenServices,
            lanceServices: lanceServices,
            salaServices: salaServices
            /*salaServices: salaServices,
            salaUsuarioServices: salaUsuarioServices*/
    };
        return service;
    }

    angular.module('cotarApp').factory(serviceId, [
        'loginServices', 'tipoUsuarioServices', 'categoriaServices', 'cotacaoServices', 'usuarioServices', 'solicitacaoServices',
        'produtoServices', 'deviceTokenServices', 'lanceServices', 'salaServices',
        services]);
})();