(function () {
    'use strict';

    var cotacaoServicesId = 'cotacaoServices';

    function cotacaoServices($http, connection) {

        function obterTodas() {
            return $http.get(connection.base() + '/cotacao/obterTodas');
        }

        function obterPorId(id) {
            return $http.get(connection.base() + '/cotacao/obterPorId/' + id);
        }

        function obterPorSolicitacaoId(id) {
            return $http.get(connection.base() + '/cotacao/obterPorSolicitacaoId/' + id);
        }

        function obterPorProdutoId(id) {
            return $http.get(connection.base() + '/cotacao/obterPorProdutoId/' + id);
        }

        function obterListaCotacoesPorProdutoId(id) {
            return $http.get(connection.base() + '/cotacao/obterListaCotacoesPorProdutoId/' + id);
        }

        function adicionar(cotacao){
            return $http.post(connection.base() + '/cotacao/adicionar', cotacao);
        }

        function editar(cotacao){
            return $http.post(connection.base() + '/cotacao/editar', cotacao);
        }

        function remover(id){
            return $http.post(connection.base() + '/cotacao/remover/'+ id);
        }

        var services = {
            obterTodas: obterTodas,
            obterPorId: obterPorId,
            obterPorSolicitacaoId: obterPorSolicitacaoId,
            obterPorProdutoId: obterPorProdutoId,
            obterListaCotacoesPorProdutoId: obterListaCotacoesPorProdutoId,
            adicionar: adicionar,
            editar: editar,
            remover: remover
        };

        return services;
    }

    angular.module('cotarApp').factory(cotacaoServicesId, ['$http', 'connection', cotacaoServices]);
})();
