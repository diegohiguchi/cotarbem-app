(function () {
    'use strict';
    var controllerId = 'cotacao.cliente';

    function cotacaoCliente(services, autenticacao, load, $state) {
        var vm = this;
        var solicitacao = {};
        vm.solicitacoes = [];

        function obterSolicitacoesPorUsuario(){
            load.showLoadingSpinner();
            services.solicitacaoServices.obterSolicitacoesPorUsuarioId(vm.usuario._id).success(function(response){
                vm.solicitacoes = response.data;
            }).error(function (err, statusCode) {
                load.hideLoading();
                load.toggleLoadingWithMessage(err.message);
            }).then(function(){
                load.hideLoading();
            });
        }

        function obterUsuario() {
            vm.usuario = autenticacao.getUser();
        }

        function activate() {
            obterUsuario();
            obterSolicitacoesPorUsuario();
        }

        vm.solicitacaoSelecionada = function (solicitacao) {

            solicitacao = angular.toJson({
                solicitacaoId: solicitacao._id,
                usuarioId: vm.usuario._id,
                usuarioNome: vm.usuario.nome,
                produtos: solicitacao.produtos,
                quantidade: solicitacao.quantidade,
                tipoCotacao: solicitacao.tipoCotacao,
                ativo: solicitacao.ativo,
                dataEntrega: solicitacao.dataEntrega,
                dataCadastro: solicitacao.dataCadastro
            });

            $state.go('app.cotacaoClienteProduto', {'solicitacao': solicitacao})
        }

        activate();
    }

    angular.module('cotarApp').controller(controllerId, ['services', 'autenticacao', 'load', '$state', cotacaoCliente]);

})();