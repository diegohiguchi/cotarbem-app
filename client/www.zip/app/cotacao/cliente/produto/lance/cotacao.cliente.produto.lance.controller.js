(function () {
    'use strict';
    var controllerId = 'cotacao.cliente.produto.lance';

    function produtoLance($state, services, $ionicHistory, load) {
        var vm = this;
        var cotacoes = []
        var sala = {};
        vm.cotacaoProduto = angular.fromJson($state.params.cotacaoProduto);

        function obterCotacoesPorSolicitacao() {
            load.showLoadingSpinner();

            services.cotacaoServices.obterPorProdutoId(vm.cotacaoProduto.produtoId).success(function (response) {
                cotacoes = response.data;
            }).error(function (err, statusCode) {
                load.hideLoading();
                load.toggleLoadingWithMessage(err.message);
            }).then(function () {
                if (cotacoes != null) {
                    services.lanceServices.obterListaLancesPorId(cotacoes.lances).success(function (response) {
                        vm.lances = response.data;
                    }).then(function(){
                        load.hideLoading();
                    });
                } else
                    load.hideLoading();
            });
        }

        function activate() {
            obterCotacoesPorSolicitacao();
        }

        vm.usuarioSelecionado = function (usuario) {
            var data = new Date();
            data = moment(data).format("DD/MM/YYYY HH:mm:ss");

            sala = angular.toJson({
                usuarioId: usuario.usuarioId,
                usuarioNome: usuario.usuarioNome,
                solicitacaoId: vm.cotacaoProduto.solicitacaoId,
                ativo: true,
                dataCadastro: data
            });

            $state.go('app.chat', {'sala': sala})
        }

        vm.voltarPagina = function(){
            $ionicHistory.goBack();
        }

        activate();
    }

    angular.module('cotarApp').controller(controllerId, ['$state', 'services', '$ionicHistory', 'load', produtoLance]);

})();