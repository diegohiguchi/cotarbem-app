(function () {
    'use strict';
    var controllerId = 'cotacao.cliente.produto';

    function cotacaoClienteProduto(services, autenticacao, load, $state) {
        var vm = this;
        var cotacaoProduto = {};
        var produtos = [];
        vm.produtos = [];
        vm.solicitacao = angular.fromJson($state.params.solicitacao);

        function obterSolicitacaoProdutos() {
            services.produtoServices.obterListaProdutosPorId(vm.solicitacao.produtos).success(function (response) {
                produtos = response.data;
            }).then(function(){
                var indice = 0;

                for (var i = 0; i < produtos.length; i++) {

                    vm.produtos.push({
                        produtoId: produtos[i]._id,
                        descricao: produtos[i].descricao,
                        urlImagem: produtos[i].urlImagem,
                        tipoCotacao: vm.solicitacao.tipoCotacao[indice],
                        quantidade: vm.solicitacao.quantidade[indice],
                        dataEntrega: vm.solicitacao.dataEntrega[indice],
                        dataCadastro: vm.solicitacao.dataCadastro
                    });

                    indice++;
                }
            });
        }

        function activate() {
            obterSolicitacaoProdutos();
        }

        vm.produtoSelecionado = function (produto) {

            cotacaoProduto = angular.toJson({
                produtoId: produto.produtoId,
                solicitacaoId: vm.solicitacao.solicitacaoId,
                descricao: produto.descricao,
                usuarioId: vm.solicitacao.usuarioId,
                usuarioNome: vm.solicitacao.usuarioNome,
                quantidade: produto.quantidade,
                tipoCotacao: produto.tipoCotacao,
                ativo: vm.solicitacao.ativo,
                dataEntrega: produto.dataEntrega,
                dataCadastro: produto.dataCadastro
            });

            $state.go('app.cotacaoClienteProdutoLance', {'cotacaoProduto': cotacaoProduto})
        }

        activate();
    }

    angular.module('cotarApp').controller(controllerId, ['services', 'autenticacao', 'load', '$state', cotacaoClienteProduto]);

})();