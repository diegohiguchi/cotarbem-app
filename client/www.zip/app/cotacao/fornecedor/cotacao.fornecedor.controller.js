(function () {
    'use strict';
    var controllerId = 'cotacao.fornecedor';

    function cotacaoFornecedor($state, services, $ionicHistory, load, $timeout) {
        var vm = this;
        var cotacoes = [];
        var lance = {};
        vm.solicitacaoProduto = angular.fromJson($state.params.solicitacaoProduto);

        function enviadoComSucesso() {
            load.showLoading('Lance enviado com sucesso.');

            $timeout(function () {
                load.hideLoading();
            }, 2000);
        }

        function obterCotacoesPorSolicitacao() {
            load.showLoadingSpinner();

            services.cotacaoServices.obterPorProdutoId(vm.solicitacaoProduto.produtoId).success(function (response) {
                cotacoes = response.data;
            }).error(function (err, statusCode) {
                load.hideLoading();
                load.toggleLoadingWithMessage(err.message);
            }).then(function () {
                if (cotacoes != null) {
                    services.lanceServices.obterListaLancesPorId(cotacoes.lances).success(function (response) {
                        vm.lances = response.data;
                        vm.solicitacaoProduto.valor = '';
                    }).then(function(){
                        load.hideLoading();
                    });
                } else
                    load.hideLoading();
            });
        }

        function formatarValor(valor) {
            if (valor != '')
                valor = valor.replace(",", ".");
            if (valor.length > 6)
                valor = valor.replace(".", "");

            return valor;
        }

        function atribuirValores(cotacaoLance, lance) {
            return {
                solicitacaoId: cotacaoLance.solicitacaoId,
                produtoId: cotacaoLance.produtoId,
                lanceId: lance._id
            }
        }

        vm.enviarLance = function (cotacaoLance) {
            load.showLoadingSpinner();
            cotacaoLance.valor = formatarValor(cotacaoLance.valor);

            services.lanceServices.adicionar(cotacaoLance).success(function (response) {
                lance = response.data;

            }).error(function (err, statusCode) {
                load.hideLoading();
                load.toggleLoadingWithMessage(err.message);

            }).then(function () {
                var cotacao = atribuirValores(cotacaoLance, lance);

                if (vm.lances != undefined && vm.lances.length > 0) {
                    services.cotacaoServices.editar(cotacao).success(function (response) {
                        obterCotacoesPorSolicitacao();
                    }).then(function(){
                        enviadoComSucesso();
                    });
                } else {
                    services.cotacaoServices.adicionar(cotacao).success(function (response) {
                        obterCotacoesPorSolicitacao();
                    }).then(function(){
                        enviadoComSucesso();
                    });
                }
            });
        }

        vm.voltarPaginaFornecedorProduto = function () {
            $ionicHistory.goBack();
        }

        function activate() {
            obterCotacoesPorSolicitacao();
        }

        activate();
    }

    angular.module('cotarApp').controller(controllerId, ['$state', 'services', '$ionicHistory', 'load', '$timeout', cotacaoFornecedor]);

})();