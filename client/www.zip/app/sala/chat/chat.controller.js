(function () {
    'use strict';
    var controllerId = 'chat';

    function chat(services, $firebaseArray, autenticacao, $state, $ionicScrollDelegate, $ionicHistory) {
        //socket.connect();
        var vm = this;
        var salas = [];
        var salaAdicionada = {};
        var sala = angular.fromJson($state.params.sala);
        var viewScroll = $ionicScrollDelegate.$getByHandle('userMessageScroll');
        vm.usuarios = [];
        vm.mensagens = [];


        vm.enviarMensagem = function (mensagem) {
            vm.mensagens.$add({
                //salaId: salaAdicionada._id,
                usuarioId: vm.usuario._id,
                usuarioNome: vm.usuario.nome,
                mensagem: mensagem,
                horario: Date.now()
            });

            vm.mensagem = "";
            $ionicScrollDelegate.scrollBottom(true);
        }

        function obterUsuario() {
            vm.usuario = autenticacao.getUser();
        }

        function obterConversas(salaId) {
            var ref = new Firebase('https://cotar.firebaseio.com/chat/' + salaId);
            vm.mensagens = $firebaseArray(ref);

            ref.child(salaId).on("child_added", function(snapshot) {
                snapshot.forEach(function(data) {
                    console.log("The " + data.key() + " dinosaur's score is " + data.val());
                });
            });

            $ionicScrollDelegate.scrollBottom(true);
        }

        function obterSala(sala) {
            services.salaServices.obterPorSolicitacaoId(sala.solicitacaoId).success(function (response) {
                salas = response.data
            }).then(function () {
                salaAdicionada = _.find(salas, {usuarioId: sala.usuarioId});
                if (!salaAdicionada)
                    criarSala(sala);
                else{
                    obterConversas(salaAdicionada._id);
                }
            });
        }

        function criarSala(sala) {
            services.salaServices.adicionar(sala).success(function (response) {
                salaAdicionada = response.data;
                obterConversas(salaAdicionada._id);
            });
        }

        /*vm.enviarMensagem = function (msg) {
            if (msg != null && msg != '')
                socket.emit('message', {
                    salaId: salaAdicionada._id,
                    usuarioId: vm.usuario._id,
                    usuarioNome: vm.usuario.nome,
                    message: msg
                })
            vm.mensagem = '';
        }*/

       /* function quebrarString(data) {
            var usuario = data.message.split("/", 1).shift();
            var usuarioId = usuario.split(" ", 1).shift();
            var usuarioNome = usuario.slice(usuarioId.split("").length + 1);
            var mensagem = data.message.slice((usuario.split("").length + 1));
            var horario = mensagem.split("/").pop();
            mensagem = mensagem.split("/", 1).shift();

            return {
                usuario: usuario,
                usuarioId: usuarioId,
                usuarioNome: usuarioNome,
                mensagem: mensagem,
                horario: horario
            }
        }*/

        //socket.on('connect',function() {
        /*socket.emit('request-usuarios', {});

        socket.on('usuarios', function (data) {
            vm.usuarios = data.usuarios;
        });

        socket.on('message', function (data) {
            vm.messages.push(data);
        });

        socket.on('message-redis', function (data) {
            var dados = quebrarString(data);

            vm.messages.push({
                message: dados.mensagem,
                usuarioId: dados.usuarioId,
                usuarioNome: dados.usuarioNome,
                horario: dados.horario
            });
        });

        socket.on('add-user', function (data) {
            console.log(vm.usuarios.indexOf(data.usuarioId));
            if (vm.usuarios.indexOf(data.usuarioId) == -1) {
                vm.usuarios.push(data.usuarioId);
                //vm.messages.push({username: data.username, message: 'entrou na sala'});
                vm.quantidadeUsuarios = vm.usuarios.length;
                console.log(vm.usuarios);
                console.log(vm.quantidadeUsuarios);
            }
        });

        socket.on('change channel', function (sala) {
            //vm.messages.push({message: 'Bem vindo a ' + sala.nome});
        });*/

        //});

        /*socket.on('remove-user', function (data) {
         console.log('Removido ' + data.usuarioId);
         vm.usuarios.splice(usuarios.indexOf(data.usuarioId), 1);
         //vm.messages.push({username: data.username, message: 'saiu da sala'});
         });*/

        /*$scope.$on('$location', function (event) {
         socket.disconnect(true);
         });
         */
        vm.voltarPagina = function () {
            $ionicHistory.goBack();
        }

        function activate() {
            vm.sala = sala;
            obterUsuario();
            //adicionarUsuarioNaSala(sala);
            obterSala(sala);
        }

        activate();
    }

    angular.module('cotarApp').controller(controllerId, ['services', '$firebaseArray', 'autenticacao', '$state', '$ionicScrollDelegate', '$ionicHistory', chat]);

})
();

/*
 (function () {
 'use strict';
 var controllerId = 'chat';

 function chat(services, autenticacao, $state, socket, $ionicScrollDelegate, $ionicHistory) {
 socket.connect();
 var vm = this;
 var salas = [];
 var salaAdicionada = {};
 var sala = angular.fromJson($state.params.sala);
 var viewScroll = $ionicScrollDelegate.$getByHandle('userMessageScroll');
 vm.usuarios = [];
 vm.messages = [];

 function obterUsuario() {
 vm.usuario = autenticacao.getUser();
 }

 function adicionarUsuarioNaSala(nome) {
 if (nome != null) {
 socket.emit('add-user', {usuarioId: sala.usuarioId, usuarioNome: sala.usuarioNome})
 }
 }

 function obterSala(sala) {
 services.salaServices.obterPorSolicitacaoId(sala.solicitacaoId).success(function (response) {
 salas = response.data
 }).then(function () {
 salaAdicionada = _.find(salas, {usuarioId: sala.usuarioId});
 if (salaAdicionada)
 socket.emit('change channel', salaAdicionada);
 else
 criarSala(sala);
 });
 }

 function criarSala(sala) {
 services.salaServices.adicionar(sala).success(function (response) {
 salaAdicionada = response.data;
 }).then(function () {
 socket.emit('change channel', salaAdicionada);
 });
 }

 vm.enviarMensagem = function (msg) {
 if (msg != null && msg != '')
 socket.emit('message', {salaId: salaAdicionada._id, usuarioId: vm.usuario._id, usuarioNome: vm.usuario.nome, message: msg})
 vm.mensagem = '';
 }

 function quebrarString(data) {
 var usuario = data.message.split("/", 1).shift();
 var usuarioId = usuario.split(" ", 1).shift();
 var usuarioNome = usuario.slice(usuarioId.split("").length + 1);
 var mensagem = data.message.slice((usuario.split("").length + 1));
 var horario = mensagem.split("/").pop();
 mensagem = mensagem.split("/", 1).shift();

 return {
 usuario: usuario,
 usuarioId: usuarioId,
 usuarioNome: usuarioNome,
 mensagem: mensagem,
 horario: horario
 }
 }

 //socket.on('connect',function() {
 socket.emit('request-usuarios', {});

 socket.on('usuarios', function (data) {
 vm.usuarios = data.usuarios;
 });

 socket.on('message', function (data) {
 vm.messages.push(data);
 });

 socket.on('message-redis', function (data) {
 var dados = quebrarString(data);

 vm.messages.push({
 message: dados.mensagem,
 usuarioId: dados.usuarioId,
 usuarioNome: dados.usuarioNome,
 horario: dados.horario
 });
 });

 socket.on('add-user', function (data) {
 console.log(vm.usuarios.indexOf(data.usuarioId));
 if (vm.usuarios.indexOf(data.usuarioId) == -1) {
 vm.usuarios.push(data.usuarioId);
 //vm.messages.push({username: data.username, message: 'entrou na sala'});
 vm.quantidadeUsuarios = vm.usuarios.length;
 console.log(vm.usuarios);
 console.log(vm.quantidadeUsuarios);
 }
 });

 socket.on('change channel', function (sala) {
 //vm.messages.push({message: 'Bem vindo a ' + sala.nome});
 });

 //});

 /!*socket.on('remove-user', function (data) {
 console.log('Removido ' + data.usuarioId);
 vm.usuarios.splice(usuarios.indexOf(data.usuarioId), 1);
 //vm.messages.push({username: data.username, message: 'saiu da sala'});
 });*!/

 /!*$scope.$on('$location', function (event) {
 socket.disconnect(true);
 });
 *!/
 vm.voltarPagina = function(){
 $ionicHistory.goBack();
 }

 function activate() {
 vm.sala = sala;
 obterUsuario();
 adicionarUsuarioNaSala(sala);
 obterSala(sala);
 }

 activate();
 }

 angular.module('cotarApp').controller(controllerId, ['services', 'autenticacao', '$state', 'socket', '$ionicScrollDelegate', '$ionicHistory', chat]);

 })
 ();*/
