(function () {
    'use strict';

    var app = angular.module('cotarApp');

    // Collect the routes
    //app.constant('routes', getRoutes());

    // Configure the routes and route resolvers
    //app.config(['$routeProvider', 'routes', routeConfigurator]);
    app.config(['$stateProvider', '$urlRouterProvider', '$httpProvider',
        function ($stateProvider, $urlRouterProvider, $httpProvider) {

            // setup the token interceptor
            $httpProvider.interceptors.push('tokenInterceptor');

            $stateProvider

                .state('login', {
                    url: "/login",
                    templateUrl: "app/usuario/autenticacao/login.html"
                })

                .state('app', {
                    url: "/app",
                    abstract: true,
                    templateUrl: "app/menu/menu.html"
                })

                .state('app.home', {
                    url: "/home",
                    views: {
                        'menuContent': {
                            templateUrl: "app/home/home.html"
                        }
                    }
                })

                .state('app.solicitacaoCliente', {
                    url: "/solicitacao/cliente",
                    views: {
                        'menuContent': {
                            templateUrl: "app/solicitacao/cliente/solicitacao.cliente.html"
                        }
                    }
                })

                .state('app.solicitacaoFornecedor', {
                    url: "/solicitacao/fornecedor",
                    views: {
                        'menuContent': {
                            templateUrl: "app/solicitacao/fornecedor/solicitacao.fornecedor.html"
                        }
                    }
                })

                .state('app.solicitacaoFornecedorProduto', {
                    url: "/solicitacao/fornecedor/:solicitacao",
                    views: {
                        'menuContent': {
                            templateUrl: "app/solicitacao/fornecedor/produto/solicitacao.fornecedor.produto.html"
                        }
                    }
                })

                .state('app.cotacaoFornecedor', {
                    url: "/cotacao/fornecedor/:solicitacaoProduto",
                    views: {
                        'menuContent': {
                            templateUrl: "app/cotacao/fornecedor/cotacao.fornecedor.html"
                        }
                    }
                })

                .state('app.cotacaoCliente', {
                    url: "/cotacao/cliente",
                    views: {
                        'menuContent': {
                            templateUrl: "app/cotacao/cliente/cotacao.cliente.html"
                        }
                    }
                })

                .state('app.cotacaoClienteProduto', {
                    url: "/cotacao/cliente/:solicitacao",
                    views: {
                        'menuContent': {
                            templateUrl: "app/cotacao/cliente/produto/cotacao.cliente.produto.html"
                        }
                    }
                })

                .state('app.cotacaoClienteProdutoLance', {
                    url: "/cotacao/cliente/produto/:cotacaoProduto",
                    views: {
                        'menuContent': {
                            templateUrl: "app/cotacao/cliente/produto/lance/cotacao.cliente.produto.lance.html"
                        }
                    }
                })

                .state('app.sala', {
                    url: "/sala",
                    views: {
                        'menuContent': {
                            templateUrl: "app/sala/sala.html"
                        }
                    }
                })

                .state('app.chat', {
                    url: "/chat/:sala",
                    views: {
                        'menuContent': {
                            templateUrl: "app/sala/chat/chat.html"
                        }
                    }
                })

                /*.state('app.sala', {
                    url: "/sala",
                    views: {
                        'menuContent': {
                            templateUrl: "app/sala/sala.html"
                        }
                    }
                })

                .state('app.salaUsuario', {
                    url: "/sala/usuario/:salaUsuario",
                    views: {
                        'menuContent': {
                            templateUrl: "app/sala/usuario/sala.usuario.html"
                        }
                    }
                })*/

                .state('app.categoria', {
                    url: "/categoria",
                    views: {
                        'menuContent': {
                            templateUrl: "app/categoria/categoria.html"
                        }
                    }
                })

                .state('app.categoriaAdicionar', {
                    url: "/categoria/adicionar",
                    views: {
                        'menuContent': {
                            templateUrl: "app/categoria/adicionar/categoria.adicionar.html"
                        }
                    }
                })

                .state('app.categoriaEditar', {
                    url: "/categoria/editar/:id",
                    views: {
                        'menuContent': {
                            templateUrl: "app/categoria/editar/categoria.editar.html"
                        }
                    }
                });

            // if none of the above states are matched, use this as the fallback
            $urlRouterProvider.otherwise('/app/home');
        }
    ])
})();