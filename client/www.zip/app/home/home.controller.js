(function () {
    'use strict';
    var controllerId = 'home';

    function home($rootScope, $location, autenticacao, services) {
        var vm = this;

        if (!$rootScope.isAuthenticated)
            $location.path('/app/login');

        function activate() {
            vm.usuario = autenticacao.getUser();

            services.tipoUsuarioServices.obterPorId(vm.usuario.tipoUsuarioId).success(function (response) {
                vm.tipoUsuario = response.data.nome;
            });
        }

        activate();
    }

    angular.module('cotarApp').controller(controllerId, ['$rootScope', '$location', 'autenticacao', 'services', home]);
    ;

})();