(function () {
    'use strict';
    var controllerId = 'menu';

    function menu($rootScope, $location, autenticacao, services, load) {
        var vm = this;

        if (!$rootScope.isAuthenticated)
            $location.path('/app/login');

        function obterTipoUsuario(){
            services.tipoUsuarioServices.obterPorId(vm.usuario.tipoUsuarioId).success(function (response) {
                vm.tipoUsuario = response.data.nome;
            });
        }

        function activate() {
            vm.usuario = autenticacao.getUser();
            obterTipoUsuario();
        }

       /* function desconectar() {
            socket.disconnect(true);
        }*/

        vm.logout = function () {
            services.loginServices.logout();
            $rootScope.isAuthenticated = false;
            $location.path('/login');
            load.toggleLoadingWithMessage('Successfully Logged Out!', 2000);

           /* if(vm.tipoUsuario === 'Fornecedor')
                desconectar();*/
        };

        activate();
    }

    angular.module('cotarApp').controller(controllerId, ['$rootScope', '$location', 'autenticacao', 'services', 'load', menu]);

})();