(function () {
    'use strict';

    var app = angular.module('cotarApp');

    app.directive('numberOnly', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attrs, modelCtrl) {

                modelCtrl.$parsers.push(function (inputValue) {
                    inputValue = inputValue || "";

                    var transformedInput = inputValue.replace(/[^0-9]/g, '');

                    if (transformedInput != inputValue) {
                        modelCtrl.$setViewValue(transformedInput);
                        modelCtrl.$render();
                    }

                    return transformedInput;
                });
            }
        };
    });

    app.directive('myCurrentTime', ['$interval', 'dateFilter', 'services',
        function ($interval, dateFilter, services) {
            // return the directive link function. (compile function not needed)
            return function (scope, element, attrs) {
                var format = 'mm:ss a',  // date format
                    stopTime,
                    solicitacao,
                    contador; // so that we can cancel the time updates

                // used to update the UI
                function updateTime() {

                    var novaData = new Date();
                    novaData = moment(novaData).format('DD/MM/YYYY HH:mm:ss');

                    var diferencaData = moment.utc(moment(novaData, "DD/MM/YYYY HH:mm:ss").diff(moment(solicitacao.dataCadastro, "DD/MM/YYYY HH:mm:ss"))).format("HH:mm:ss");
                    var tempoEmSegundos = moment.duration(diferencaData).asSeconds();

                    if (tempoEmSegundos <= 600) {
                        var intervaloData = moment.utc(moment(solicitacao.dataCadastro, "DD/MM/YYYY HH:mm:ss").diff(moment(novaData, "DD/MM/YYYY HH:mm:ss"))).format("HH:mm:ss");
                        contador = moment.utc(moment(intervaloData, "HH:mm:ss").diff(moment("23:50:00", "HH:mm:ss"))).format("mm:ss");
                        //mytimeout = setTimeout(criarTemporizador(solicitacao), 1000);
                    } else if (solicitacao.ativo) {
                        solicitacao.ativo = false;
                        services.solicitacaoServices.editar(solicitacao).success(function (response) {
                            $interval.cancel(stopTime);
                        }).then(function () {
                            var device = {};
                            device = {
                                usuarioId: solicitacao.usuarioId,
                                mensagem: 'Nova cota&ccedil;&acirc;o'
                            }

                            services.deviceTokenServices.notificar(device).success(function () {
                            });
                        });

                    } else {
                        $interval.cancel(stopTime);
                    }

                    element.text(dateFilter(contador, format));
                }

                // watch the expression, and update the UI on change.
                scope.$watch(attrs.myCurrentTime, function (value) {
                    ///format = value;
                    solicitacao = value;
                    updateTime();
                });

                stopTime = $interval(updateTime, 1000);

                // listen on DOM destroy (removal) event, and cancel the next UI update
                // to prevent updating time after the DOM element was removed.
                element.on('$destroy', function () {
                    $interval.cancel(stopTime);
                });
            }
        }]);

    app.directive('obterNome', ['services',
        function (services) {
            // return the directive link function. (compile function not needed)
            return function (scope, element, attrs) {
                var usuarioId;

                function obterUsuario() {
                    services.usuarioServices.obterPorId(usuarioId).success(function (response) {
                        element.text(response.data.nome);
                    });
                }

                scope.$watch(attrs.obterNome, function (value) {
                    usuarioId = value;
                    obterUsuario();
                });
            }
        }]);

    app.directive('autolinker', ['$timeout',
        function ($timeout) {
            return {
                restrict: 'A',
                link: function (scope, element, attrs) {
                    $timeout(function () {
                        var eleHtml = element.html();

                        if (eleHtml === '') {
                            return false;
                        }

                        var text = Autolinker.link(eleHtml, {
                            className: 'autolinker',
                            newWindow: false
                        });

                        element.html(text);

                        var autolinks = element[0].getElementsByClassName('autolinker');

                        for (var i = 0; i < autolinks.length; i++) {
                            angular.element(autolinks[i]).bind('click', function (e) {
                                var href = e.target.href;
                                console.log('autolinkClick, href: ' + href);

                                if (href) {
                                    //window.open(href, '_system');
                                    window.open(href, '_blank');
                                }

                                e.preventDefault();
                                return false;
                            });
                        }
                    }, 0);
                }
            }
        }
    ]);

    app.directive('dinheiroMask', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attrs, modelCtrl) {
                var formataValor = function (valor) {
                    valor = valor.replace(/[^0-9]+/g, '').replace(/^0+/, '');

                    if (valor.length == 1) {
                        valor = "0,0" + valor;
                        return valor;
                    }

                    if (valor.length == 2) {
                        valor = "0," + valor;
                        return valor;
                    }

                    if (valor.length > 2) {
                        var centavos = valor.substring(valor.length - 2);

                        valor = valor.substring(0, valor.length - 2) + "," + centavos;
                    }

                    if (valor.length > 6) {
                        var centenas = valor.substring(valor.length - 6);

                        valor = valor.substring(0, valor.length - 6) + "." + centenas;
                    }

                    return valor;
                };

                element.bind('keyup', function (key) {
                    if (key.keyCode != 37 && key.keyCode != 39 && key.keyCode != 8) {
                        var valor = modelCtrl.$viewValue;
                        modelCtrl.$setViewValue(formataValor(valor));
                        modelCtrl.$render();
                    }
                });
            },
        };
    });
})()
