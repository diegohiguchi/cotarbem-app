(function () {
    'use strict';
    var controllerId = 'solicitacao.fornecedor';

    function solicitacaoFornecedor(services, autenticacao, load, $state) {
        var vm = this;
        var solicitacao = {};
        var solicitacoes = [];
        vm.solicitacoes = [];

        function obterUsuario() {
            var usuario = autenticacao.getUser();

            services.usuarioServices.obterPorId(usuario._id).success(function (response) {
                vm.usuario = response.data;
            }).then(function () {
                //obterSolicitacoesPorCategoriaId();
                obterSolicitacoes();
            });
        }

        function activate() {
            obterUsuario();
        }

        function obterSolicitacoes() {
            load.showLoadingSpinner();

            services.solicitacaoServices.obterListaSolicitacoesPorCategoriaId(vm.usuario.categorias).success(function (response) {
                solicitacoes = response.data;
            }).error(function (err, statusCode) {
                load.hideLoading();
                load.toggleLoadingWithMessage(err.message);
            }).then(function () {

                for (var i = 0; i < solicitacoes.length; i++) {
                    vm.solicitacoes.push({
                        solicitacaoId: solicitacoes[i]._id,
                        usuarioId: solicitacoes[i].usuarioId,
                        categoriaId: solicitacoes[i].categoriaId,
                        ativo: solicitacoes[i].ativo,
                        dataCadastro: solicitacoes[i].dataCadastro,
                        dataEntrega: solicitacoes[i].dataEntrega,
                        quantidade: solicitacoes[i].quantidade,
                        tipoCotacao: solicitacoes[i].tipoCotacao,
                        produtos: solicitacoes[i].produtos
                    });
                }

                load.hideLoading();
            });
        }

        /*function obterSolicitacoes(){
         services.solicitacaoServices.obterTodas().success(function(response){
         var solicitacoes = response.data;

         vm.usuario.categorias.forEach(function (categoriaId){
         var filtroSolicitacoes = _.filter(solicitacoes, {categoriaId: categoriaId});
         if(filtroSolicitacoes){
         filtroSolicitacoes.forEach(function(solicitacao){
         vm.solicitacoes.push({
         solicitacaoId: solicitacao._id,
         usuarioId: solicitacao.usuarioId,
         categoriaId: solicitacao.categoriaId,
         ativo: solicitacao.ativo,
         dataCadastro: solicitacao.dataCadastro,
         dataEntrega: solicitacao.dataEntrega,
         quantidade: solicitacao.quantidade,
         tipoCotacao: solicitacao.tipoCotacao,
         produtos: solicitacao.produtos
         });
         });
         }
         });
         });
         }*/

        /* function obterSolicitacoesPorCategoriaId() {

         vm.usuario.categorias.forEach(function (categoriaId) {
         services.solicitacaoServices.obterSolicitacoesPorCategoriaId(categoriaId).success(function (response) {
         var solicitacao = response.data;
         if (response.data != '') {
         solicitacao.forEach(function(solicitacao){
         vm.solicitacoes.push({
         solicitacaoId: solicitacao._id,
         usuarioId: solicitacao.usuarioId,
         categoriaId: solicitacao.categoriaId,
         ativo: solicitacao.ativo,
         dataCadastro: solicitacao.dataCadastro,
         dataEntrega: solicitacao.dataEntrega,
         quantidade: solicitacao.quantidade,
         tipoCotacao: solicitacao.tipoCotacao,
         produtos: solicitacao.produtos
         });
         });
         }
         });
         });
         }*/

        vm.solicitacaoSelecionada = function (solicitacao) {

            solicitacao = angular.toJson({
                solicitacaoId: solicitacao.solicitacaoId,
                descricao: solicitacao.descricao,
                usuarioId: vm.usuario._id,
                usuarioNome: vm.usuario.nome,
                produtos: solicitacao.produtos,
                quantidade: solicitacao.quantidade,
                tipoCotacao: solicitacao.tipoCotacao,
                ativo: solicitacao.ativo,
                dataEntrega: solicitacao.dataEntrega,
                dataCadastro: solicitacao.dataCadastro
            });

            $state.go('app.solicitacaoFornecedorProduto', {'solicitacao': solicitacao})
        }

        activate();
    }

    angular.module('cotarApp').controller(controllerId, ['services', 'autenticacao', 'load', '$state', solicitacaoFornecedor]);

})();