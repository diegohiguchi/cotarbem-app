(function () {
    'use strict';
    var controllerId = 'solicitacao.fornecedor.produto';

    function solicitacaoFornecedorProduto(services, autenticacao, load, $state) {
        var vm = this;
        var solicitacaoProduto = {};
        var produtos = [];
        vm.produtos = [];
        vm.solicitacao = angular.fromJson($state.params.solicitacao);

        /*function obterSolicitacaoProdutos() {
            services.produtoServices.obterTodos().success(function (response) {
                var produtos = response.data;
                var indice = 0;

                for (var i = 0; i < vm.solicitacao.produtos.length; i++) {
                    var filtroSolicitacaoProduto = _.find(produtos, {_id: vm.solicitacao.produtos[i]});

                    if (filtroSolicitacaoProduto) {
                        vm.produtos.push({
                            produtoId: filtroSolicitacaoProduto._id,
                            descricao: filtroSolicitacaoProduto.descricao,
                            urlImagem: filtroSolicitacaoProduto.urlImagem,
                            tipoCotacao: vm.solicitacao.tipoCotacao[indice],
                            quantidade: vm.solicitacao.quantidade[indice],
                            dataEntrega: vm.solicitacao.dataEntrega[indice],
                            dataCadastro: vm.solicitacao.dataCadastro
                        });

                        indice++;
                    }
                }
            });
        }*/

        function obterSolicitacaoProdutos() {
             services.produtoServices.obterListaProdutosPorId(vm.solicitacao.produtos).success(function (response) {
                 produtos = response.data;
             }).then(function(){
                 var indice = 0;

                 for (var i = 0; i < produtos.length; i++) {

                     vm.produtos.push({
                         produtoId: produtos[i]._id,
                         descricao: produtos[i].descricao,
                         urlImagem: produtos[i].urlImagem,
                         tipoCotacao: vm.solicitacao.tipoCotacao[indice],
                         quantidade: vm.solicitacao.quantidade[indice],
                         dataEntrega: vm.solicitacao.dataEntrega[indice],
                         dataCadastro: vm.solicitacao.dataCadastro
                     });

                     indice++;
                 }
             });
         }

        /*   function obterSolicitacoesPorCategoriaId() {
         var indice = 0;

         for (var i = 0; i < vm.solicitacao.produtos.length; i++) {
         services.produtoServices.obterPorId(vm.solicitacao.produtos[i]).success(function (response) {
         vm.produtos.push({
         produtoId: response.data._id,
         descricao: response.data.descricao,
         urlImagem: response.data.urlImagem,
         tipoCotacao: vm.solicitacao.tipoCotacao[indice],
         quantidade: vm.solicitacao.quantidade[indice],
         dataEntrega: vm.solicitacao.dataEntrega[indice],
         dataCadastro: vm.solicitacao.dataCadastro
         });

         indice++;
         });
         }
         }*/

        function activate() {
            //obterSolicitacoesPorCategoriaId();
            obterSolicitacaoProdutos();
        }

        vm.produtoSelecionado = function (produto) {

            solicitacaoProduto = angular.toJson({
                produtoId: produto.produtoId,
                solicitacaoId: vm.solicitacao.solicitacaoId,
                descricao: produto.descricao,
                usuarioId: vm.solicitacao.usuarioId,
                usuarioNome: vm.solicitacao.usuarioNome,
                quantidade: produto.quantidade,
                tipoCotacao: produto.tipoCotacao,
                ativo: vm.solicitacao.ativo,
                dataEntrega: produto.dataEntrega,
                dataCadastro: produto.dataCadastro
            });

            $state.go('app.cotacaoFornecedor', {'solicitacaoProduto': solicitacaoProduto})
        }

        activate();
    }

    angular.module('cotarApp').controller(controllerId, ['services', 'autenticacao', 'load', '$state', solicitacaoFornecedorProduto]);

})();