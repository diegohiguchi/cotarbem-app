(function () {
    'use strict';
    var controllerId = 'solicitacao.cliente';

    function solicitacaoCliente($rootScope, $location, services, autenticacao, load, $timeout, $cordovaCamera, $ionicPopup) {
        var vm = this;
        var solicitacao = [];
        var usuariosId = [];
        var produtos = [];
        var nomeArquivo = '';
        var tipoCotacoes = [];
        var quantidade = [];
        var dataEntrega = [];
        var usuarios = [];
        vm.imagem = {};
        vm.produtos = [];
        vm.categorias = [];

        vm.solicitacao = {
            categoria: {},
            tipoCotacao: {}
        };

        if (!$rootScope.isAuthenticated)
            $location.path('/app/login');

        function obterCategorias() {
            services.categoriaServices.obterTodas().success(function (response) {
                vm.categorias = response.data;
            });
        }

        function obterUsuario() {
            vm.solicitacao.usuario = autenticacao.getUser();
        }

        function obterCotacao() {
            vm.tipoCotacao = [{
                tipoCotacaoId: 0,
                nome: 'Unidade'
            }, {
                tipoCotacaoId: 1,
                nome: 'Caixa'
            }];

            vm.solicitacao.tipoCotacao = vm.tipoCotacao[0];
        }

        vm.obterUsuariosPorCategoria = function (categoria) {
            services.usuarioServices.obterFornecedoresPorCategoriaId(categoria._id).success(function (response) {
                usuarios = response.data;
            });
        }

        function activate() {
            vm.statusForm = false;
            obterCategorias();
            obterUsuario();
            obterCotacao();
        }

        function adicionadoComSucesso() {
            load.showLoading('Solicita&ccedil;&atilde;o enviada com sucesso.');

            $timeout(function () {
                load.hideLoading();
            }, 3000);
        }

        vm.processarArquivos = function (files) {
            angular.forEach(files, function (flowFile, i) {
                nomeArquivo = flowFile.name;
                var fileReader = new FileReader();
                fileReader.onload = function (event) {
                    var uri = imageResizer(event.target.result);
                    vm.imagem = {
                        nome: nomeArquivo,
                        url: uri,
                        files: files
                    };

                };
                fileReader.readAsDataURL(flowFile.file);
            });
        };

        vm.limparArquivos = function (files) {
            angular.forEach(files, function (flowFile, i) {
                flowFile.cancel();
                vm.imagem = {
                    nome: '',
                    url: '',
                    files: ''
                };
            });
        }

        function atribuirValores(solicitacao, tipoCotacoes, quantidade, dataEntrega, produtos) {
            var data = new Date();

            return {
                usuarioId: solicitacao.usuario._id,
                produtos: produtos,
                categoriaId: solicitacao.categoria._id,
                tipoCotacao: tipoCotacoes,
                quantidade: quantidade,
                ativo: true,
                dataEntrega: dataEntrega,
                dataCadastro: moment(data).format('DD/MM/YYYY HH:mm:ss')
            }
        }

        function salvarSolicitacao(solicitacao) {
            services.solicitacaoServices.solicitar(solicitacao).success(function (response) {
                solicitacao = response.data;
                adicionadoComSucesso();
            }).error(function (err, statusCode) {
                load.hideLoading();
                load.toggleLoadingWithMessage(err.message);
            });
        }

        function notificarFornecedores() {
            usuarios.forEach(function (usuario) {
                var device = {
                    usuarioId: usuario._id,
                    mensagem: 'Nova solicita&ccedil;&atilde;o'
                }
                services.deviceTokenServices.notificar(device).success(function (response) {
                });
            });
        }

        function salvarProduto(solicitacao) {
            load.showLoadingSpinner();

            vm.produtos.forEach(function (produto) {
                var novoProduto = {
                    descricao: produto.descricao,
                    //nomeImagem: produto.nomeImagem,
                    urlImagem: produto.urlImagem
                }

                tipoCotacoes.push(produto.tipoCotacao.tipoCotacaoId);
                quantidade.push(produto.quantidade);
                dataEntrega.push(produto.dataEntrega);

                services.produtoServices.adicionar(novoProduto).success(function (response) {
                    produtos.push(response.data._id);
                }).then(function (response) {
                    if (produtos.length == vm.produtos.length) {
                        var novaSolicitacao = atribuirValores(solicitacao, tipoCotacoes, quantidade, dataEntrega, produtos);
                        salvarSolicitacao(novaSolicitacao);
                        produtos = [];
                        vm.limparTodosCampos();
                        vm.statusForm = true;
                    }
                }).then(function () {
                    notificarFornecedores();
                });

                novoProduto = {};
            });
        }

        vm.solicitar = function (solicitacao) {
            if (solicitacao.descricaoProduto != undefined && solicitacao.categoria != undefined
                && solicitacao.quantidade != undefined && vm.solicitacao.dataEntrega != undefined)
                vm.adicionarProduto(solicitacao);
            else if (solicitacao.categoria == undefined) {
                vm.statusForm = false;
                return;
            } else if (vm.produtos <= 0) {
                vm.statusForm = false;
                return;
            }

            salvarProduto(solicitacao);
        }

        vm.adicionarProduto = function (solicitacao) {
            vm.produtos.push({
                descricao: solicitacao.descricaoProduto,
                //nomeImagem: vm.imagem.nome,
                urlImagem: vm.imagemSrc,
                tipoCotacao: solicitacao.tipoCotacao,
                quantidade: solicitacao.quantidade,
                dataEntrega: moment(solicitacao.dataEntrega).format('DD/MM/YYYY')
            });

            vm.solicitacao = {
                usuario: vm.solicitacao.usuario,
                categoria: solicitacao.categoria,
                tipoCotacao: vm.tipoCotacao[0]
            };
            //vm.limparArquivos(vm.imagem.files);
            vm.retirarImagem();
        }

        vm.removerProduto = function (produto) {
            vm.produtos.splice(vm.produtos.indexOf(produto), 1);
        }

        vm.retirarImagem = function () {
            $cordovaCamera.cleanup();
            vm.imagemSrc = '';
        }

        vm.limparTodosCampos = function () {
            vm.produtos = [];
            vm.solicitacao = {};
            vm.retirarImagem();
            //vm.limparArquivos(vm.imagem.files);
            vm.solicitacao.tipoCotacao = vm.tipoCotacao[0];
            obterUsuario();
        }

        vm.showPopup = function () {
            var myPopup = $ionicPopup.show({
                //templateUrl: 'popupImagem.html',
                title: 'Escolher imagem',
                cssClass: '.popup-buttons .button',
                buttons: [{ // Array[Object] (optional). Buttons to place in the popup footer.
                    text: 'C&acirc;mera',
                    type: 'button icon-left ion-camera button-clear button-dark',
                    onTap: function (e) {
                        // e.preventDefault() will stop the popup from closing when tapped.
                        return vm.tirarFoto();
                    }
                }, {
                    text: 'Documentos',
                    type: 'button icon-left ion-android-list button-clear button-dark',
                    onTap: function (e) {
                        // Returning a value will cause the promise to resolve with the given value.
                        return vm.selecionarFoto();
                    }
                }]
            });
        };

        vm.tirarFoto = function () {
            var options = {
                quality: 75,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.CAMERA,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 300,
                targetHeight: 300,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false
                //correctOrientation: true
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                //var image = document.getElementById('myImage');
                vm.imagemSrc = "data:image/jpeg;base64," + imageData;
            }, function (err) {
                // error
            });
        }

        vm.selecionarFoto = function () {
            var options = {
                quality: 75,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 300,
                targetHeight: 300,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                vm.imagemSrc = "data:image/jpeg;base64," + imageData;
            }, function (err) {
                // An error occured. Show a message to the user
            });
        }

        activate();
    }

    angular.module('cotarApp').controller(controllerId, ['$rootScope', '$location', 'services', 'autenticacao', 'load', '$timeout', '$cordovaCamera', '$ionicPopup', solicitacaoCliente]);
})();